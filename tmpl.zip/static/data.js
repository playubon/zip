// null data
alert("haha")